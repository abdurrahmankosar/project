package com.example.lab08.myapplication3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class Second1Activity extends AppCompatActivity {

    ImageView iv ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second1);
new bekle().start();
            iv=findViewById(R.id.imageView);

            }

            private class bekle extends Thread{

                public void  run () {

                    super.run();

                   try {

                       Thread.sleep(5000);


                   }catch (Exception e)

                   {


                   }

                    Intent intent =new Intent(getApplicationContext(),MainActivity.class);
                   startActivity(intent);
                finish();

                }
                }





            }

