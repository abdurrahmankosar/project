package com.example.myapplication4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    EditText et1, et2;
    ImageView iv ;
    Button btn1 ;
      String dizi[]={"Abdullah","Ali"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1=findViewById(R.id.button1);
        et1=findViewById(R.id.editText1);
        et2=findViewById(R.id.editText2);
        iv=findViewById(R.id.imageView);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            if (dizi[0].equals(et1.getText().toString())) {


                Intent intent = new Intent(MainActivity.this, Secondactivity.class);

                startActivity(intent);


            }





            }
        });



    }
}
