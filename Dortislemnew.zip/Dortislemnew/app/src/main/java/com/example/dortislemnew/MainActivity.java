package com.example.dortislemnew;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView textTopla , textCikar , textCarp,textBol ;
Typeface tf ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textTopla=findViewById(R.id.textTopla);
        textCikar=findViewById(R.id.textCikar);
        textCarp=findViewById(R.id.textCarp);
        textBol=findViewById(R.id.textBol);
        tf=Typeface.createFromAsset(getAssets(),"fonts/bluefires_sample.ttf");

        textBol.setTypeface(tf);
        textCarp.setTypeface(tf);
        textCikar.setTypeface(tf);
        textTopla.setTypeface(tf);


         textTopla.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent = new Intent(getApplicationContext(),topla_Activity.class);
                 startActivity(intent);
             }
         });




    }
}
