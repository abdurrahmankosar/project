package com.example.dortislemnew;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

public class topla_Activity extends AppCompatActivity {

    TextView tv ;
    ImageView iv ;
    Button btn20,btn12,btn30,btn15 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topla_);

       tv=findViewById(R.id.textSoru1);
        iv=findViewById(R.id.imageView2);
        btn12=findViewById(R.id.btn12);
        btn15=findViewById(R.id.btn15);
        btn20=findViewById(R.id.btn20);
        btn30=findViewById(R.id.btn30);


        btn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn12.setBackgroundColor(Color.RED);
            }
        });

        btn20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn20.setBackgroundColor(Color.RED);
            }
        });


        btn30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn30.setBackgroundColor(Color.RED);
            }
        });

        btn15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn15.setBackgroundColor(Color.GREEN);
            }
        });





    }
}
