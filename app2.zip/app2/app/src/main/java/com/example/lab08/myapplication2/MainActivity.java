package com.example.lab08.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText et1,et2,et3 ;
    TextView tv1,tv2,tv3 ;
  Button btn1 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         btn1=findViewById(R.id.btn1);
        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        et3=findViewById(R.id.et3);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(MainActivity.this,SecondActivity.class);

                intent.putExtra("adsoyad",et1.getText().toString());
                intent.putExtra("uni",et2.getText().toString());
                intent.putExtra("sınıf",et3.getText().toString());

                startActivity(intent);

            }
        });


    }
}
