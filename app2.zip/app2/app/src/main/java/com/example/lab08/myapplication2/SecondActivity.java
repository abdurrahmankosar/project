package com.example.lab08.myapplication2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class SecondActivity extends AppCompatActivity {

    EditText ett1,ett2,ett3 ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

          ett1=findViewById(R.id.editText);
          ett2=findViewById(R.id.editText2);
          ett3=findViewById(R.id.editText3);

        String adsoyad =getIntent().getStringExtra("adsoyad");

       ett1.setText(adsoyad);


        String uni =getIntent().getStringExtra("uni");

        ett2.setText(uni);


        String sınıf =getIntent().getStringExtra("sınıf");

        ett3.setText(sınıf);
    }
}
